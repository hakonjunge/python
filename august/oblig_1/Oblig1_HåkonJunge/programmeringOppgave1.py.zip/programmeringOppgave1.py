text = ("Hello world!")
print(text)
#Dette er et eksempel på en hello_world kode
#En variabel med string som sier hello world! og print, som skriver variablen