def calculateVolum(lengde, bredde, høyde): return lengde * bredde * høyde


# Lager en funksjon som regner sammen l*b*h og definerer parametrene
print(calculateVolum(4, 3, 4))
print(calculateVolum(6, 2, 5))
print(calculateVolum(9, 18, 45))
# Kjører funksjonen  3 ganger med forskjellige verdier
