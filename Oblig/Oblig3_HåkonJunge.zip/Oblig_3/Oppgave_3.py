def my_function(favorites):
  for middagsretter in favorites:
    # Skriver det som en loop sånn at det blir oversiktlig
    print(middagsretter)
my_favorites = ["Taco", "Pizza", "Lasagne"] #Pizza er en fredagsrett og taco er en lørdagsrett
my_function(my_favorites)
#Det er lov å ha ananas på pizza, det er bare kontroversiellt