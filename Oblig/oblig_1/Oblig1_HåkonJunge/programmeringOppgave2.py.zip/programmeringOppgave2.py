first_name = "Håkon"
last_name = "Junge"
age = "21"
print("Hei. Jeg heter {} {} og er {} år gammel".format(first_name, last_name, age))
#Her har jeg laget variabler med verdier
#Jeg har lagt variablene inn i teksten