test_number1 = input("Skriv det første tall ")
test_number2 = input("Skriv det andre tall ")
test_number1 = float(test_number1)
test_number2 = float(test_number2)
#Første del ber om tall

print(f"Tallene du skrev var {test_number1} og {test_number2}")

print(f"Gange: {test_number1}*{test_number2}={test_number1*test_number2}")

print(f"Dele: {test_number1}/{test_number2}={test_number1/test_number2}")

print(f"Pluss: {test_number1}+{test_number2}={test_number1+test_number2}")

print(f"Minus: {test_number1}-{test_number2}={test_number1-test_number2}")

print(f"Modulo: {test_number1}%{test_number2}={test_number1%test_number2}")

print(f"Opphøyde: {test_number1}**{test_number2}={test_number1**test_number2}")

print(f"Dele med nedrunding: {test_number1}//{test_number2}={test_number1//test_number2}")
#Andre del printer ut regnestykkene
