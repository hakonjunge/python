a = 6
b = 3
c = 2
#Har laget variabler med int verdier

print(f"a + b * c = {a+b*c}")
print(f"( a + b ) * c = {(a+b)*c}")
print(f"a / b / c = {a/b/c}")
print(f"a / ( b / c ) = {a/(b/c)}")
#Lagt til variablene i regnestykker